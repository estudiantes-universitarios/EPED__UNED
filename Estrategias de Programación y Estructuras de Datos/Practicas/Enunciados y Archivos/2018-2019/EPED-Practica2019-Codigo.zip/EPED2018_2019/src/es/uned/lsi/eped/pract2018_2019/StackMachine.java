package es.uned.lsi.eped.pract2018_2019;

public class StackMachine {

	
	public StackMachine() {
	}
	
	public Operand execute(SynTree syn) {
		return (new Operand("0"));
	}
	
}
